# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .ogb_dataset_lookup_table import OGBDatasetLookupTable
